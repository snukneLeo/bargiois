
<div class="toast align-items-center text-white bg-primary border-0" id="added" role="alert" aria-live="assertive"
    aria-atomic="true">
    <div class="d-flex">
        <form action="<?php echo e(route('home')); ?>" method="get" enctype="multipart/form-data" class="form-group">
            <?php echo csrf_field(); ?>
            <div class="toast-body">
                Wait, new order is added! Please refresh the page to show new orders.
                <button type="submit" class="btn btn-primary" aria-label="save">
                    <i class="fas fa-sync-alt"></i>
                </button>
            </div>
        </form>
    </div>
</div>


<div class="toast align-items-center text-white bg-danger border-0" id="deleted" role="alert" aria-live="assertive"
    aria-atomic="true">
    <div class="d-flex">
        <form action="<?php echo e(route('home')); ?>" method="get" enctype="multipart/form-data" class="form-group">
            <?php echo csrf_field(); ?>
            <div class="toast-body">
                Wait, an order is deleted! Please refresh the page to show orders.
                <button type="submit" class="btn btn-danger" aria-label="save">
                    <i class="fas fa-sync-alt"></i>
                </button>
            </div>
        </form>
    </div>
</div>
<?php /**PATH C:\Workspace\gestionale2\resources\views/layouts/toast/toast.blade.php ENDPATH**/ ?>