<h1>Ciao</h1>
<form action="<?php echo e(route('index.page')); ?>" method="POST">
    <button type="submit">Press here </button>
</form><?php /**PATH C:\Workspace\gestionale2\resources\views/partials/login.blade.php ENDPATH**/ ?>