<div class="container mt-5">
    <div class="row">
        <div class="col"></div>
        <div class="col">
            <form action="<?php echo e(route('auth.login')); ?>" method="POST">
                <div class="mb-3">
                  <label for="username" class="form-label">Username</label>
                  <input type="username" class="form-control" name="username">
                </div>
                <div class="mb-3">
                  <label for="exampleInputPassword1" class="form-label">Password</label>
                  <input type="password" class="form-control" name="password">
                </div>
                <button type="submit" class="btn btn-primary">Sign in</button>
                <button type="submit" class="btn btn-primary">Register</button>
            </form>
        </div>
        <div class="col"></div>
    </div>
</div><?php /**PATH C:\Workspace\gestionale2\resources\views/components/login/login.blade.php ENDPATH**/ ?>