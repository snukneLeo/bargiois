<form method="POST" action="<?php echo e(route('save.total')); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="mb-3 qt_pasta">
        <label for="" class="form-label">Qt Pasta</label>
        <input type="text" class="form-control" name="qt_total_pasta" id="qt_pasta">
    </div>
    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
        <button type="submit" class="btn btn-success">
            <i class="fas fa-save"></i>
        </button>
    </div>
</form>
<?php /**PATH C:\Workspace\gestionale2\resources\views/layouts/form/form_total_pasta.blade.php ENDPATH**/ ?>